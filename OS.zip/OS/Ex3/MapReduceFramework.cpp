//
// Created by pnina on 24/06/2024.
//

#include <atomic>
#include <csignal>
#include <iostream>
#include <algorithm>
#include <semaphore.h>

#include "MapReduceClient.h"
#include "MapReduceFramework.h"
#include "Barrier.h"


#define ALLOCATION_FAILURE "system error: failed to allocate memory"
#define INITIALIZE_SEMAPHORE_FAILURE "system error: initialize semaphore failed"
#define SEM_FAILURE "system error: semaphore failure"
#define MUTEX_FAILURE_LOCK "system error: failed to lock the mutex"
#define MUTEX_FAILURE_UNLOCK "system error: failed to unlock the mutex"
#define DESTROY_SEMAPHORE_FAILURE "system error: destroying semaphore failed"
#define DESTROY_MUTEX_FAILURE "system error: destroying mutex failed"
#define THREAD_JOIN_FAILURE "system error: failed to join thread"
#define MAIN_THREAD 0
#define PERCENTAGE 100
#define MAP_PHASE 1UL << 62
#define SHUFFLE_PHASE 2UL << 62
#define REDUCE_PHASE 3UL << 63
#define INDEX 0x7FFFFFFF
#define INC_PROCESSED 0x80000000UL
#define PROCESSED 0x3FFFFFFF80000000

using namespace std;

typedef struct {
    int thread_id;
    struct JobContext* job;
    IntermediateVec *pairsFromMap;
    int counter_num_of_intermediate;

} ThreadContext;

typedef struct JobContext {
    const MapReduceClient *client; // map and reduce functions
    const InputVec *inputVec;
    size_t size_input_vec;
    OutputVec *outputVec;
    int MultiThreadLevel;

    atomic<uint64_t> *counter_job;
    atomic<uint64_t>* processed;
    atomic<uint64_t>* totalToProcess;
    //atomic<uint64_t>* totalIntermediatePairs;
    int num_of_intermediate;

    pthread_mutex_t* join_mutex;
    pthread_mutex_t *state_mutex;
    pthread_mutex_t *mtx;
    //pthread_cond_t *cv;
    pthread_mutex_t *emit2_mutex;
    pthread_mutex_t *emit3_mutex;
    pthread_mutex_t *reduce_mutex;
    sem_t* semaphore;

//    bool* mapStageStart;
//    bool* shuffleStageStart;
    bool reduceStageStart;

    vector<pthread_t*> *array_of_threads;
    vector<ThreadContext*>* array_of_thread_context;
    JobState *state;
    vector<IntermediateVec*> *map_results_threads;
    vector<IntermediatePair>* all_Intermediate;
    Barrier *barrier;
    vector<IntermediateVec*> *shuffle_Vec;
    size_t shuffle_vec_size;
    vector<bool> is_joined;

} JobContext;

void exit_failure(int retVal, const char * msg){
    if (retVal != 0) {
        std::cout << msg << endl;
        exit(EXIT_FAILURE);
    }
}


// first stage of the algorithm
void MapPhase(ThreadContext* tc) {
    JobContext *job = tc->job;

    exit_failure(pthread_mutex_lock(job->state_mutex),MUTEX_FAILURE_LOCK);

    // update the stage of the job
    job->state->stage = MAP_STAGE;

    exit_failure(pthread_mutex_unlock(job->state_mutex), MUTEX_FAILURE_UNLOCK);

    while (true) {
        // Atomic fetch and increment operation
        uint64_t oldValue = (*job->counter_job)++;

        // Check if all input pairs have been processed
        if ((oldValue) >= job->inputVec->size()) {
            break;
        }

        // Extract index from counter_value
        InputPair pair = (*job->inputVec)[oldValue];
        job->client->map(pair.first, pair.second, (void*)tc);

        // Update progress
        job->processed->fetch_add(1);

       // update percentages
        exit_failure(pthread_mutex_lock(job->state_mutex), MUTEX_FAILURE_LOCK);
        job->state->percentage = (static_cast<float>(job->processed->load())
                / job->totalToProcess->load()) * 100;
        exit_failure(pthread_mutex_unlock(job->state_mutex),
                     MUTEX_FAILURE_UNLOCK);
    }

}
// comparator
bool comparator(const IntermediatePair &first_tuple, const IntermediatePair &
second_tuple) {
    return (first_tuple.first->operator<(*second_tuple.first));

}

bool compare_keys(const K2 &first_tuple, const K2 &second_tuple){
    return !(first_tuple.operator<(second_tuple)) && !(second_tuple
    .operator<(first_tuple));
}


void SortPhase(ThreadContext *tc) {
    std::sort(tc->pairsFromMap->begin(), tc->pairsFromMap->end(), comparator);
    exit_failure(pthread_mutex_lock(tc->job->mtx), MUTEX_FAILURE_LOCK);
    tc->job->map_results_threads->push_back(tc->pairsFromMap);
    tc->job->num_of_intermediate += tc->pairsFromMap->size();
    //tc->job->totalIntermediatePairs->fetch_add(tc->pairsFromMap->size());
    exit_failure(pthread_mutex_unlock(tc->job->mtx), MUTEX_FAILURE_UNLOCK);
}

K2* get_max_key(ThreadContext *tc){
    IntermediatePair *max_pair;
    K2 *maxKey = nullptr;
    for (const auto &vec : *tc->job->map_results_threads){
        if (vec->size() == 0)
            continue;
        max_pair = &vec->at(vec->size()-1);
        if (maxKey == nullptr){
            maxKey = max_pair->first;
        }
        else if (*maxKey < *(max_pair->first)){
            maxKey = max_pair->first;
        }

    }
    return maxKey;
}

bool is_results_map_empty(ThreadContext* tc){
    for(auto vec : (*tc->job->map_results_threads)){
        if (!vec->empty())
            return false;
    }
    return true;
}

void ShufflePhase(ThreadContext *tc) {

    tc->job->state->stage = SHUFFLE_STAGE;
    tc->job->state->percentage = 0;
    tc->job->processed->store(0);
    tc->job->totalToProcess->store((tc->job->num_of_intermediate));
    vector<IntermediateVec *> *thread_vec = tc->job->map_results_threads;

    K2 *curMaxKey;
    while (!is_results_map_empty(tc)){

        curMaxKey = get_max_key(tc);
        auto *new_seq_vec = new IntermediateVec();
        for (int vec = thread_vec->size()-1; vec >=0; vec--){
            while (!thread_vec->at(vec)->empty() &&
                    compare_keys(*curMaxKey, *thread_vec->at
                    (vec)->back().first)) {
                IntermediatePair *pair = &thread_vec->at(vec)->back();
                thread_vec->at(vec)->pop_back();
                tc->job->processed->fetch_add(1);
                new_seq_vec->push_back(*pair);
            }

        }
        tc->job->shuffle_Vec->push_back(new_seq_vec);
        tc->job->state->percentage = (static_cast<float>
                (tc->job->processed->load())
                                  / tc->job->totalToProcess->load()) * 100;
    }

}

void ReducePhase(ThreadContext* tc){

 //   exit_failure(pthread_mutex_lock(tc->job->state_mutex),
   //               MUTEX_FAILURE_LOCK);
//    if (!(tc->job->reduceStageStart)){
//
//    tc->job->state->stage = REDUCE_STAGE;
//    tc->job->state->percentage = 0;
//    tc->job->processed->store(0);
//    tc->job->counter_job->store(0);
//    tc->job->totalToProcess->store(tc->job->num_of_intermediate);
//    (tc->job->reduceStageStart) = true;
//    }
 //   exit_failure(pthread_mutex_unlock(tc->job->state_mutex),
   //              MUTEX_FAILURE_UNLOCK);

    while (true){
        uint64_t oldValue = (*tc->job->counter_job)++;
        if (oldValue >= tc->job->shuffle_Vec->size()){
            break;
        }
        const IntermediateVec *vec = (*tc->job->shuffle_Vec)[oldValue];
        tc->job->client->reduce(vec, (void*)tc);
        tc->job->processed->fetch_add(vec->size());
        exit_failure(pthread_mutex_lock(tc->job->state_mutex),MUTEX_FAILURE_LOCK);

        tc->job->state->percentage = (static_cast<float>
                (tc->job->processed->load())
                                  / tc->job->totalToProcess->load()) * 100;
        exit_failure(pthread_mutex_unlock(tc->job->state_mutex),
                     MUTEX_FAILURE_UNLOCK);
    }

}

void emit3 (K3* key, V3* value, void* context){
    auto *tc = (ThreadContext*) context;
    exit_failure(pthread_mutex_lock(tc->job->reduce_mutex),
                 MUTEX_FAILURE_LOCK);
    tc->job->outputVec->push_back(OutputPair(key, value));
    exit_failure(pthread_mutex_unlock(tc->job->reduce_mutex), MUTEX_FAILURE_UNLOCK);


}

void emit2(K2 *key, V2 *value, void *context) {
    auto *tc = (ThreadContext *) context;
    IntermediatePair pair(key, value);
    exit_failure(pthread_mutex_lock(tc->job->emit2_mutex), MUTEX_FAILURE_LOCK);
    tc->pairsFromMap->push_back(pair);

    exit_failure(pthread_mutex_unlock(tc->job->emit2_mutex),
                 MUTEX_FAILURE_UNLOCK);
}


void initialize_mutex(const JobContext *job) {

    exit_failure(pthread_mutex_init(job->state_mutex, nullptr),
                 ALLOCATION_FAILURE);
    exit_failure(pthread_mutex_init(job->reduce_mutex, nullptr),
                 ALLOCATION_FAILURE);
    exit_failure(pthread_mutex_init(job->mtx, nullptr),
                 ALLOCATION_FAILURE);
    exit_failure(pthread_mutex_init(job->emit2_mutex, nullptr),
                 ALLOCATION_FAILURE);
    exit_failure(pthread_mutex_init(job->emit3_mutex, nullptr),
                 ALLOCATION_FAILURE);
    exit_failure(pthread_mutex_init(job->join_mutex, nullptr),
                 ALLOCATION_FAILURE);
}

JobContext *initialize_job_context(const MapReduceClient &
client, const InputVec &inputVec, OutputVec &outputVec, int multiThreadLevel) {

    auto *job = new JobContext;
    job->state = new JobState{UNDEFINED_STAGE, 0.0};
    job->client = &client;
    job->inputVec = &inputVec;
    job->size_input_vec = inputVec.size();
    job->outputVec = &outputVec;
    job->MultiThreadLevel = multiThreadLevel;

    job->counter_job = new atomic<uint64_t>(0);
    job->processed = new atomic<uint64_t>(0);
    job->totalToProcess = new atomic<uint64_t>(inputVec.size());
    //job->totalIntermediatePairs = new atomic<uint64_t>(0);
    job->num_of_intermediate = 0;


//    //initialize mutexes
    job->state_mutex = new(nothrow) pthread_mutex_t;
    job->reduce_mutex = new(nothrow) pthread_mutex_t;
    job->join_mutex = new(nothrow) pthread_mutex_t;
    job->mtx = new(nothrow) pthread_mutex_t;
    //job->cv = new(nothrow) pthread_cond_t;
    job->emit2_mutex = new(nothrow) pthread_mutex_t;
    job->emit3_mutex = new(nothrow) pthread_mutex_t;
    job->semaphore = new(nothrow) sem_t;
    initialize_mutex(job);
    if (sem_init(job->semaphore, 0, 0)!=0){
        std::cout << INITIALIZE_SEMAPHORE_FAILURE << endl;
        exit(EXIT_FAILURE);
    }
//    job->mapStageStart = new bool(false);
   // job->shuffleStageStart = new bool(false);
    job->reduceStageStart = false;

    job->array_of_threads = new vector<pthread_t *>();
    job->array_of_thread_context = new vector<ThreadContext *>();

    job->map_results_threads = new vector<IntermediateVec *>();
    job->shuffle_Vec = new vector<IntermediateVec *>();
    job->barrier = new Barrier(job->MultiThreadLevel);

    return job;
}


// every thread will run this
void *job_to_do(void *arg) {
    auto *tc = static_cast<ThreadContext *>(arg);

    MapPhase(tc);

    SortPhase(tc);
    tc->job->barrier->barrier(); //

    if (tc->thread_id != MAIN_THREAD){
        if (sem_wait(tc->job->semaphore)!=0){
            std::cout << SEM_FAILURE << endl;
            exit(EXIT_FAILURE);
        }
    }
    else{
        ShufflePhase(tc);
        tc->job->state->stage = REDUCE_STAGE;
        tc->job->state->percentage = 0;
        tc->job->counter_job->store(0);
        tc->job->processed->store(0);
        tc->job->totalToProcess->store(tc->job->num_of_intermediate);
    }
    if (sem_post(tc->job->semaphore)!=0){
        std::cout << SEM_FAILURE << endl;
        exit(EXIT_FAILURE);
    }

    //tc->job->barrier->barrier();
    ReducePhase(tc);
    return nullptr;
}

// initialize the MapReduce
JobHandle startMapReduceJob(const MapReduceClient &client,
                            const InputVec &inputVec, OutputVec &outputVec,
                            int multiThreadLevel) {

    JobContext* job = initialize_job_context(client, inputVec, outputVec,multiThreadLevel);


    exit_failure(pthread_mutex_lock(job->join_mutex),
                 MUTEX_FAILURE_LOCK);
    for (int i=0; i < multiThreadLevel; i++) {
        auto *threadContext = new ThreadContext();
        threadContext->thread_id = i;
        threadContext->job = job;
        threadContext->pairsFromMap = new IntermediateVec();
        threadContext->counter_num_of_intermediate = 0;

        auto *newThread = new pthread_t;
        job->array_of_threads->push_back(newThread);
        job->array_of_thread_context->push_back(threadContext);
        job->is_joined.push_back(false);
        int created_thread = pthread_create(newThread, nullptr, job_to_do,
                                            threadContext);
        if (created_thread != 0) {
            std::cout << ALLOCATION_FAILURE << endl;
            exit(EXIT_FAILURE);
        }
    }
    exit_failure(pthread_mutex_unlock(job->join_mutex),
                 MUTEX_FAILURE_UNLOCK);

    return job;
}

void getJobState(JobHandle job, JobState* state) {

    auto *jobContext = (JobContext*)job;

    exit_failure(pthread_mutex_lock(jobContext->state_mutex),
                 MUTEX_FAILURE_LOCK);

    state->stage = jobContext->state->stage;
    state->percentage = jobContext->state->percentage;
    exit_failure(pthread_mutex_unlock(jobContext->state_mutex),
                 MUTEX_FAILURE_UNLOCK);

}

void waitForJob(JobHandle job){
    auto *jc = (JobContext *) job;
    exit_failure(pthread_mutex_lock(jc->join_mutex), MUTEX_FAILURE_LOCK);

    // Check if the threads have already been joined

    // Join all threads
    for (int i = 0; i < jc->MultiThreadLevel; i++) {
        if (!jc->is_joined.at(i)){
            exit_failure(pthread_join(*jc->array_of_threads->at(i), nullptr)
                         , THREAD_JOIN_FAILURE);

            jc->is_joined[i] = true;
        }
    }

    exit_failure(pthread_mutex_unlock(jc->join_mutex), MUTEX_FAILURE_UNLOCK);
}

void closeJobHandle(JobHandle job){

    auto* jobContext = (JobContext*)job;
    waitForJob(job);
    for (int i=0; i< jobContext->MultiThreadLevel; i++){
        pthread_t *thread = jobContext->array_of_threads->at(i);
        delete thread;
    }


    exit_failure(pthread_mutex_destroy(jobContext->mtx),
                 DESTROY_MUTEX_FAILURE);
    exit_failure(pthread_mutex_destroy(jobContext->emit2_mutex),
                 DESTROY_MUTEX_FAILURE);
    exit_failure(pthread_mutex_destroy(jobContext->emit3_mutex),
                 DESTROY_MUTEX_FAILURE);
    exit_failure(pthread_mutex_destroy(jobContext->state_mutex),
                 DESTROY_MUTEX_FAILURE);

    exit_failure(pthread_mutex_destroy(jobContext->join_mutex),
                 DESTROY_MUTEX_FAILURE);
    exit_failure(pthread_mutex_destroy(jobContext->reduce_mutex),
                 DESTROY_MUTEX_FAILURE);
    exit_failure(sem_destroy(jobContext->semaphore),
                 DESTROY_SEMAPHORE_FAILURE);

    delete jobContext->mtx;
    delete jobContext->emit2_mutex;
    delete jobContext->emit3_mutex;
    delete jobContext->state_mutex;
    delete jobContext->join_mutex;
    delete jobContext->reduce_mutex;

    delete jobContext->barrier;
    delete jobContext->counter_job;
    delete jobContext->processed;
    delete jobContext->totalToProcess;


    for (int i=0; i< jobContext->MultiThreadLevel; i++){
        ThreadContext* threadContext =
                jobContext->array_of_thread_context->at(i);
        delete threadContext->pairsFromMap;
        delete threadContext;
    }


    delete jobContext->array_of_threads;
    delete jobContext->array_of_thread_context;

    delete jobContext->shuffle_Vec;
    delete jobContext->state;
    delete jobContext->map_results_threads;


    delete jobContext;
}